//
//  AppSetting.swift
//  FruitMart
//
//  Created by 박경춘 on 2023/01/31.
//  Copyright © 2023 Giftbot. All rights reserved.
//

import Foundation

struct AppSetting{
    var showFavoriteList: Bool = true
    var productRowHeight: CGFloat = 150
}
