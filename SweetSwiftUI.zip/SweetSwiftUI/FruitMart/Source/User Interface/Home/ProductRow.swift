//
//  ProductRow.swift
//  FruitMart
//
//  Created by 박경춘 on 2023/01/18.
//  Copyright © 2023 Giftbot. All rights reserved.
//

import SwiftUI

struct ProductRow: View {
    
    let product: Product
    @EnvironmentObject var store: Store
    @Binding var quickOrder: Product?
    @State private var willAppear: Bool = false
    
    var body: some View {
        HStack{
            productImage
            productDescripton
        }
        .frame(height: store.appSetting.productRowHeight)
        .opacity(willAppear ? 1 : 0)
        .animation(.easeInOut(duration: 0.4))
        .onAppear { self.willAppear = true } 
        
        .frame(height: 150)
        .background(Color.primary.colorInvert())
        .cornerRadius(6)
        .shadow(color: Color.primaryShaodw, radius: 1, x: 2, y: 2)
        .padding(.vertical, 8)
        .contextMenu { contextMenu }
    }
    
}

private extension ProductRow {
    var productImage: some View{
        Image(product.imageName)
            .resizable()
            .scaledToFill()
            .frame(width: 140)
            .clipped()
    }
    
    var footerView: some View {
        HStack(spacing: 0){
            Text("\(product.price)").font(.headline) + Text("원").font(.headline)
            
            Spacer()
            
            FavoriteButton(product: product)
            
            Text("  ")
            
            Symbol("cart", color: .peach)
                .frame(width: 32, height: 32)
                .onTapGesture {
                    self.orderProduct()
                }
            
        }
        
    }
    
    var productDescripton: some View{
        VStack(alignment: .leading) {
            Text(product.name)
                .font(.headline)
                .fontWeight(.medium)
                .padding(.bottom, 6)
            
            Text(product.description)
                .font(.footnote)
                .foregroundColor(.secondary)
            
            Spacer()
            footerView
        }
        .padding([.leading, .bottom], 12)
        .padding([.top, .trailing])
        
        
    
    }
    
    var contextMenu: some View {
      VStack {
        Button(action: { self.toggleFavorite() }) {
          Text("Toggle Favorite")
          Symbol(self.product.isFavorite ? "heart.fill" : "heart")
        }
        Button(action: { self.orderProduct() }) {
          Text("Order Product")
          Symbol("cart")
        }
      }
    }
    
    func orderProduct(){
        quickOrder = product
        store.placeOrder(product: product, quantity: 1)
    }
    
    func toggleFavorite() {
      store.toggleFavorite(of: product)
    }
}

struct ProductRow_Previews: PreviewProvider {
    static var previews: some View {
        //ProductRow(product: productSamples[0])
        Group{
            ForEach(productSamples){
                ProductRow(product: $0, quickOrder: .constant(nil))
            }
            ProductRow(product: productSamples[0], quickOrder: .constant(nil))
                .preferredColorScheme(.dark)
        }
        
        .padding()
        .previewLayout(.sizeThatFits)
    }
}
