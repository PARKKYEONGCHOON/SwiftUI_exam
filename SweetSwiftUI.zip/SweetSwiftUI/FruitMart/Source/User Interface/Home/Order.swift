//
//  Order.swift
//  FruitMart
//
//  Created by 박경춘 on 2023/01/27.
//  Copyright © 2023 Giftbot. All rights reserved.
//

import Foundation

struct Order: Identifiable {
    
    static var orderSequence = sequence(first: lastOrderID + 1) { $0 &+ 1 }
    static var lastOrderID: Int {
      get { UserDefaults.standard.integer(forKey: "LastOrderID") }
      set { UserDefaults.standard.set(newValue, forKey: "LastOrderID") }
    }
    
    let id: Int
    let product: Product
    let quantity: Int
    
    var price: Int {
        product.price * quantity
    }
    
    
}

extension Order: Codable {}
