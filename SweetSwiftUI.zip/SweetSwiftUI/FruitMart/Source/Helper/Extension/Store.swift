//
//  Store.swift
//  FruitMart
//
//  Created by 박경춘 on 2023/01/20.
//  Copyright © 2023 Giftbot. All rights reserved.
//

import Foundation

final class Store: ObservableObject {
    
    @Published var appSetting: AppSetting
    @Published var products: [Product]
    @Published var orders: [Order] = []
    
    init(filename: String = "ProductData.json", appSetting: AppSetting = AppSetting()) {
        self.products = Bundle.main.decode(filename: filename, as: [Product].self)
        self.appSetting = appSetting
    }
    
    func placeOrder(product: Product, quantity: Int) {
        let nextID = Order.orderSequence.next()!
        let order = Order(id: nextID, product: product, quantity: quantity)
        orders.append(order)
        Order.lastOrderID = nextID
    }
    
    func deleteOrder(at indexes: IndexSet) {
        guard let index = indexes.first else { return }
        orders.remove(at: index)
    }
    
    func moveOrder(from indexes: IndexSet, to destination: Int){
        orders.move(fromOffsets: indexes, toOffset: destination)
    }
}

extension Store {
    func toggleFavorite(of product: Product){
        guard let index = products.firstIndex(of: product)
        else { return }
        products[index].isFavorite.toggle()
    }
}
