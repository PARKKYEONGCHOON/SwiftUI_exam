//
//  ColorExtension.swift
//  FruitMart
//
//  Created by 박경춘 on 2023/01/18.
//  Copyright © 2023 Giftbot. All rights reserved.
//

import SwiftUI

extension Color {
    
    
    static let peach = Color("peach")
    static let primaryShaodw = Color.primary.opacity(0.2)
    static let secondaryText = Color(hex: "#6e6e6e")
    static let background = Color(UIColor.systemGray6)
    
}

extension Color {
    init(hex: String){
        let scanner = Scanner(string: hex)
        _ = scanner.scanString("#")
        
        var rgb: UInt64 = 0
        scanner.scanHexInt64(&rgb)
        
        let r = Double((rgb >> 16) & 0xFF)
        let g = Double((rgb >> 8) & 0xFF)
        let b = Double((rgb >> 0) & 0xFF)
        
        self.init(red: r, green: g, blue: b)
    }
}
