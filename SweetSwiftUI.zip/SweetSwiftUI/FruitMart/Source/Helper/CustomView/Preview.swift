//
//  Preview.swift
//  FruitMart
//
//  Created by 박경춘 on 2023/01/26.
//  Copyright © 2023 Giftbot. All rights reserved.
//

import SwiftUI

struct Preview<V: View>: View {
    
    enum Device: String, CaseIterable {
        case iphone8 = "iphone8"
        case iphone11 = "iphone11"
        case iphone11pro = "iphone11 pro"
        case iphone14pro = "iphone14 pro"
    }
    
    let source: V
    var devices: [Device] = [.iphone11pro, .iphone14pro, .iphone8]
    var displayDarkMode: Bool = true
    
    var body: some View {
        Group{
            ForEach(devices, id: \.self){
                self.previewSource(device: $0)
            }
            
            if devices.isEmpty && displayDarkMode {
                self.previewSource(device: devices[0])
                    .preferredColorScheme(.dark)
            }
        }
    }
    
    private func previewSource(device: Device) -> some View{
        source
            .previewDevice(PreviewDevice(rawValue: device.rawValue))
            .previewDisplayName(device.rawValue)
    }
}

struct Preview_Previews: PreviewProvider {
    static var previews: some View {
        Preview(source: Text("dasdas"))
    }
}
